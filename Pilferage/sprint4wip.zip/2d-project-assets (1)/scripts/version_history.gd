extends Control


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	#connects button signals
	$BackButton.pressed.connect(on_backbutton_pressed)
func on_backbutton_pressed():
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
